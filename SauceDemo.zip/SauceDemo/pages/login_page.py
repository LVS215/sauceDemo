from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class LoginPage:
    """Page Object для страницы логина SauceDemo"""
    
    # Локаторы
    USERNAME_INPUT = (By.ID, "user-name")
    PASSWORD_INPUT = (By.ID, "password")
    LOGIN_BUTTON = (By.ID, "login-button")
    ERROR_MESSAGE = (By.CSS_SELECTOR, "[data-test='error']")
    
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)
        self.base_url = "https://www.saucedemo.com/"
    
    def open(self):
        """Открыть страницу логина"""
        self.driver.get(self.base_url)
        self.wait.until(EC.visibility_of_element_located(self.LOGIN_BUTTON))
    
    def login(self, username, password):
        """Выполнить вход"""
        self.wait.until(EC.visibility_of_element_located(self.USERNAME_INPUT))
        
        # Очистка полей (на случай предыдущих данных)
        self.driver.find_element(*self.USERNAME_INPUT).clear()
        self.driver.find_element(*self.PASSWORD_INPUT).clear()
        
        # Ввод данных
        self.driver.find_element(*self.USERNAME_INPUT).send_keys(username)
        self.driver.find_element(*self.PASSWORD_INPUT).send_keys(password)
        
        # Клик по кнопке входа
        self.driver.find_element(*self.LOGIN_BUTTON).click()
    
    def get_error_message(self):
        """Получить текст сообщения об ошибке"""
        try:
            error_element = self.wait.until(
                EC.visibility_of_element_located(self.ERROR_MESSAGE)
            )
            return error_element.text
        except:
            return ""